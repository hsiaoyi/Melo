//--------------------------------------------------------------------------------
//	File		: MLPlatform.h
//	Description	: 
//	Author		: Chang, Hsiao-Yi
//
//	Copyright (c) 2014-2015. All rights reserved.
//	https://github.com/hsiaoyi/Melo
//--------------------------------------------------------------------------------

#ifndef __ML_PLATFORM_H__
#define __ML_PLATFORM_H__


#ifdef WIN32
#define ML_WIN32
//#pragma message("========MELO win32========")

#endif	// WIN32



#endif	// __ML_PLATFORM_H__